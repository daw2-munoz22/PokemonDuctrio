module RfSettings
    # disable this if you encounter any issues/incompatibilities involving map display positioning
    # as it overwrites Game_Player's screen position logic
    ENABLE_MAP_LOCKING = true
end